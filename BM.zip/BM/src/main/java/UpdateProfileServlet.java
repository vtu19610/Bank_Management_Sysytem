import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.example.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/UpdateProfileServlet")
public class UpdateProfileServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve account number from session
        HttpSession session = request.getSession();
        String accountNumber = (String) session.getAttribute("accountNumber");

        if (accountNumber == null) {
            response.sendRedirect("customerLogin.jsp");
            return;
        }

        // Retrieve updated profile information from form data
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String mobileNumber = request.getParameter("mobileNumber");
        String address = request.getParameter("address");

        // Update profile in the database
        Connection con = null;
        PreparedStatement pst = null;

        try {
            con = DatabaseConnection.initializeDatabase();
            String query = "UPDATE customers SET name = ?, email = ?, mobile_number = ?, address = ? WHERE account_number = ?";
            pst = con.prepareStatement(query);
            pst.setString(1, name);
            pst.setString(2, email);
            pst.setString(3, mobileNumber);
            pst.setString(4, address);
            pst.setString(5, accountNumber);
            int rowsUpdated = pst.executeUpdate();

            if (rowsUpdated > 0) {
                // Profile updated successfully
                response.sendRedirect("customerDashboard.jsp?msg=Profile updated successfully.");
            } else {
                // Failed to update profile
                response.sendRedirect("customerDashboard.jsp?error=Failed to update profile. Please try again.");
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            response.sendRedirect("customerDashboard.jsp?error=Database error occurred. Please try again later.");
        } finally {
            try {
                if (pst != null) pst.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
