package com.example;


import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/deleteCustomer")
public class DeleteCustomerServlet extends HttpServlet {
    private static final long serialVersionUID = 1L; 

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try {
            String accountNumber = request.getParameter("accountNumber");

            if (accountNumber != null && !accountNumber.isEmpty()) {
                CustomerDAO customerDAO = new CustomerDAO();
                boolean deleted = customerDAO.deleteCustomerByAccountNumber(accountNumber);

                if (deleted) {
                    request.setAttribute("message", "Account with account number " + accountNumber + " has been successfully deleted.");
                } else {
                    request.setAttribute("message", "Failed to delete account with account number " + accountNumber + ".");
                }
            } else {
                request.setAttribute("message", "Invalid account number.");
            }
            request.getRequestDispatcher("deleteCustomer.jsp").forward(request, response);
        } catch (Exception e) {
            request.setAttribute("message", "Error: " + e.getMessage());
            request.getRequestDispatcher("deleteCustomer.jsp").forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
}
