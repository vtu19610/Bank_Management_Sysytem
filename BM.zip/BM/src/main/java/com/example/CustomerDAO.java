package com.example;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CustomerDAO {

    private static final String SELECT_CUSTOMER_BY_ACCOUNT_NUMBER =
            "SELECT * FROM customers WHERE account_number = ?";
    
    private static final String UPDATE_CUSTOMER =
            "UPDATE customers SET full_name = ?, address = ?, mobile_no = ?, email = ?, id_proof = ?, account_type = ?, dob = ?, is_closed = ? WHERE account_number = ?";
    
    private static final String DELETE_CUSTOMER =
            "DELETE FROM customers WHERE account_number = ?";

    // Method to get database connection
    private Connection getConnection() throws SQLException {
        try {
            // Load the MySQL JDBC driver class
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            // Handle the class not found exception (e.g., log it)
            e.printStackTrace();
            throw new SQLException("Database driver not found");
        }

        // Establish the database connection using DatabaseConnection class
        try {
            return DatabaseConnection.initializeDatabase();
        } catch (ClassNotFoundException e) {
            // Handle the class not found exception (e.g., log it)
            e.printStackTrace();
            throw new SQLException("Database connection initialization failed: " + e.getMessage());
        }
    }

    // Method to retrieve customer by account number
    public Customer getCustomerByAccountNumber(String accountNumber) {
        Customer customer = null;
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(SELECT_CUSTOMER_BY_ACCOUNT_NUMBER)) {
            statement.setString(1, accountNumber);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                customer = extractCustomerFromResultSet(resultSet);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return customer;
    }

    // Method to update customer details
    public boolean updateCustomer(Customer customer) {
        boolean rowUpdated = false;
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(UPDATE_CUSTOMER)) {
            setStatementParameters(statement, customer);
            statement.setString(9, customer.getAccountNumber());

            rowUpdated = statement.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rowUpdated;
    }

    // Method to delete customer by account number
    public boolean deleteCustomerByAccountNumber(String accountNumber) {
        boolean deleted = false;
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(DELETE_CUSTOMER)) {
            statement.setString(1, accountNumber);

            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                deleted = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return deleted;
    }

    // Extracts customer details from ResultSet
    private Customer extractCustomerFromResultSet(ResultSet resultSet) throws SQLException {
        Customer customer = new Customer();
        customer.setAccountNumber(resultSet.getString("account_number"));
        customer.setFullName(resultSet.getString("full_name"));
        customer.setAddress(resultSet.getString("address"));
        customer.setMobileNumber(resultSet.getString("mobile_no"));
        customer.setEmail(resultSet.getString("email"));
        customer.setIdProof(resultSet.getString("id_proof"));
        customer.setAccountType(resultSet.getString("account_type"));
        customer.setDob(resultSet.getDate("dob"));
        customer.setIsClosed(resultSet.getInt("is_closed"));
        return customer;
    }

    // Sets PreparedStatement parameters for customer update
    private void setStatementParameters(PreparedStatement statement, Customer customer) throws SQLException {
        statement.setString(1, customer.getFullName());
        statement.setString(2, customer.getAddress());
        statement.setString(3, customer.getMobileNumber());
        statement.setString(4, customer.getEmail());
        statement.setString(5, customer.getIdProof());
        statement.setString(6, customer.getAccountType());
        statement.setDate(7, new java.sql.Date(customer.getDob().getTime()));
        statement.setInt(8, customer.getIsClosed());
    }
}
