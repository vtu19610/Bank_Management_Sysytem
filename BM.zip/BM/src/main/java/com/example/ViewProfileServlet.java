package com.example;

import java.io.IOException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/viewProfile")
public class ViewProfileServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve customer account number from request parameter
        String accountNumber = request.getParameter("accountNumber");
        
        if (accountNumber != null && !accountNumber.isEmpty()) {
            CustomerDAO customerDAO = new CustomerDAO();
            Customer customer = customerDAO.getCustomerByAccountNumber(accountNumber);
            
            if (customer != null) {
                // Format date of birth
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                String formattedDob = dateFormat.format(customer.getDob());
                
                // Set attributes to be accessed in JSP
                request.setAttribute("accountNumber", customer.getAccountNumber());
                request.setAttribute("fullName", customer.getFullName());
                request.setAttribute("address", customer.getAddress());
                request.setAttribute("mobileNumber", customer.getMobileNumber());
                request.setAttribute("email", customer.getEmail());
                request.setAttribute("dob", formattedDob);
                request.setAttribute("idProof", customer.getIdProof());
                request.setAttribute("accountType", customer.getAccountType()); // Set accountType
                
                // Forward to JSP to display profile
                request.getRequestDispatcher("/viewCustomer.jsp").forward(request, response);
            } else {
                // Handle case where customer is not found
                response.getWriter().println("Customer not found or invalid account number.");
            }
        } else {
            // Handle case where account number parameter is missing or empty
            response.getWriter().println("Invalid account number parameter.");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
