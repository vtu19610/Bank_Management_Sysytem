package com.example;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/ViewTransactions")
public class ViewTransactionsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String accountNumber = (String) session.getAttribute("accountNumber");

        if (accountNumber == null) {
            response.sendRedirect("customerLogin.jsp");
            return;
        }

        String filterType = request.getParameter("filterType");

        List<Transaction> transactions = new ArrayList<>();
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            con = DatabaseConnection.initializeDatabase();
            String query;
            if (filterType != null && !filterType.isEmpty()) {
                query = "SELECT * FROM transactions WHERE account_number = ? AND transaction_type = ? ORDER BY transaction_date DESC";
                pst = con.prepareStatement(query);
                pst.setString(1, accountNumber);
                pst.setString(2, filterType);
            } else {
                query = "SELECT * FROM transactions WHERE account_number = ? ORDER BY transaction_date DESC";
                pst = con.prepareStatement(query);
                pst.setString(1, accountNumber);
            }
            
            rs = pst.executeQuery();

            while (rs.next()) {
                Transaction transaction = new Transaction();
                transaction.setTransactionId(rs.getInt("transaction_id"));
                transaction.setAmount(rs.getDouble("amount"));
                transaction.setTransactionDate(rs.getDate("transaction_date"));
                transaction.setTransactionType(rs.getString("transaction_type"));
                transactions.add(transaction);
            }

            request.setAttribute("transactions", transactions);
            RequestDispatcher dispatcher = request.getRequestDispatcher("viewTransactions.jsp");
            dispatcher.forward(request, response);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            request.setAttribute("errorMsg", "Database error occurred. Please try again later.");
            RequestDispatcher dispatcher = request.getRequestDispatcher("customerDashboard.jsp");
            dispatcher.forward(request, response);
        } finally {
            try {
                if (rs != null) rs.close();
                if (pst != null) pst.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}