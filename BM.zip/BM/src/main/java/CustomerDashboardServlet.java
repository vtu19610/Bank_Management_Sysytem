
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/customerDashboard")
public class CustomerDashboardServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Ensure the user is logged in
        HttpSession session = request.getSession();
        String customerAccountNo = (String) session.getAttribute("customerAccountNo");
        
        if (customerAccountNo == null) {
            // If not logged in, redirect to login page
            response.sendRedirect("customerLogin.jsp");
        } else {
            // Fetch customer details from the database
            Connection con = null;
            PreparedStatement pst = null;
            ResultSet rs = null;
            
            try {
                con = DatabaseConnection.initializeDatabase();
                String query = "SELECT * FROM customers WHERE account_number = ?";
                pst = con.prepareStatement(query);
                pst.setString(1, customerAccountNo);
                rs = pst.executeQuery();
                
                if (rs.next()) {
                    // Retrieve customer details from the result set
                    String fullName = rs.getString("full_name");
                    String address = rs.getString("address");
                    String mobileNo = rs.getString("mobile_no");
                    String email = rs.getString("email");
                    String accountType = rs.getString("account_type");
                    double balance = rs.getDouble("balance"); // Adjusted from initial_balance
                    String dob = rs.getString("dob"); // Assuming dob is stored as a string for simplicity
                    
                    // Set customer details as request attributes
                    request.setAttribute("fullName", fullName);
                    request.setAttribute("address", address);
                    request.setAttribute("mobileNo", mobileNo);
                    request.setAttribute("email", email);
                    request.setAttribute("accountType", accountType);
                    request.setAttribute("balance", balance);
                    request.setAttribute("dob", dob);
                    
                    // Forward the request to the customer dashboard JSP
                    RequestDispatcher dispatcher = request.getRequestDispatcher("customerDashboard.jsp");
                    dispatcher.forward(request, response);
                } else {
                    // If no customer found with the given account number, handle appropriately
                    response.getWriter().write("Customer not found.");
                }
            } catch (SQLException | ClassNotFoundException e) {
                e.printStackTrace();
                response.getWriter().write("Error: " + e.getMessage());
            } finally {
                // Close resources in finally block
                try {
                    if (rs != null) rs.close();
                    if (pst != null) pst.close();
                    if (con != null) con.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Handle POST requests if needed
        // For example, processing form submissions or other actions
        // This depends on your application's requirements
    }
}
