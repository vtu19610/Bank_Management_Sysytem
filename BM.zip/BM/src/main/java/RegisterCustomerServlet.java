import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Random;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/registerCustomer")
public class RegisterCustomerServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String fullName = request.getParameter("fullName");
        String address = request.getParameter("address");
        String mobileNo = request.getParameter("mobileNo");
        String emailId = request.getParameter("emailId");
        String accountType = request.getParameter("accountType");
        double initialBalance = Double.parseDouble(request.getParameter("initialBalance"));
        String dob = request.getParameter("dob");
        String idProof = request.getParameter("idProof");

        Random rand = new Random();
        String accountNo = String.format("%08d", rand.nextInt(100000000));
        String tempPassword = String.format("%04d", rand.nextInt(10000));

        try {
            Connection connection = DatabaseConnection.initializeDatabase();
            String sql = "INSERT INTO customer (full_name, address, mobile_no, email_id, account_type, balance, dob, id_proof, account_no, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, fullName);
            statement.setString(2, address);
            statement.setString(3, mobileNo);
            statement.setString(4, emailId);
            statement.setString(5, accountType);
            statement.setDouble(6, initialBalance);
            statement.setString(7, dob);
            statement.setString(8, idProof);
            statement.setString(9, accountNo);
            statement.setString(10, tempPassword);
            statement.executeUpdate();

            response.sendRedirect("adminDashboard.jsp?message=Customer registered successfully. Account No: " + accountNo + ", Temp Password: " + tempPassword);
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
