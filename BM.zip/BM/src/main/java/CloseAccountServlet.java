import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/CloseAccountServlet")
public class CloseAccountServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String accountNumber = (String) session.getAttribute("accountNumber");

        if (accountNumber == null) {
            response.sendRedirect("customerLogin.jsp");
            return;
        }

        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            con = DatabaseConnection.initializeDatabase();

            // Check account balance
            String checkBalanceQuery = "SELECT balance FROM customers WHERE account_number = ?";
            pst = con.prepareStatement(checkBalanceQuery);
            pst.setString(1, accountNumber);
            rs = pst.executeQuery();

            if (rs.next()) {
                double balance = rs.getDouble("balance");
                if (balance != 0) {
                    request.setAttribute("message", "Account balance must be zero to close the account. Please withdraw your money.");
                    request.getRequestDispatcher("closeAccount.jsp").forward(request, response);
                    return;
                }
            } else {
                request.setAttribute("message", "Account not found.");
                request.getRequestDispatcher("closeAccount.jsp").forward(request, response);
                return;
            }

            // Close account
            String closeAccountQuery = "UPDATE customers SET is_closed = 1 WHERE account_number = ?";
            pst = con.prepareStatement(closeAccountQuery);
            pst.setString(1, accountNumber);
            int rowCount = pst.executeUpdate();

            if (rowCount > 0) {
                session.invalidate();
                request.setAttribute("messageType", "success");
                request.setAttribute("message", "Your account has been closed successfully. Thank you for banking with us.");

                
                request.setAttribute("message", "Your account has been closed successfully. Thank you for banking with us.");
                request.getRequestDispatcher("closeAccount.jsp").forward(request, response);
            } else {
                request.setAttribute("message", "Failed to close account.");
             // Error case
     
                request.setAttribute("message", "Failed to close account. Please try again later.");
                request.getRequestDispatcher("closeAccount.jsp").forward(request, response);
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            request.setAttribute("message", "Database error occurred. Please try again later.");
            request.getRequestDispatcher("closeAccount.jsp").forward(request, response);
        } finally {
            try {
                if (rs != null) rs.close();
                if (pst != null) pst.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
